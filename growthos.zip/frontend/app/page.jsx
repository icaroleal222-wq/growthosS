export default function Home() {
  return <h1>GrowthOS is live 🚀</h1>;
}
