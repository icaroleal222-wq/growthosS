module.exports = {
  output: "standalone"
};
